<?php

namespace App\Classes;

abstract class AbstractExtension
{
    abstract public static function getConfig(): array;
}
