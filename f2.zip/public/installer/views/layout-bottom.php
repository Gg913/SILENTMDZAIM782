
<!-- top layout here -->

<!-- any middle view here -->


    <footer class="fixed bottom-0 left-0 right-0 bg-[#1D2125] bg-opacity-20 text-center py-2 text-xs">
        &copy; <?php echo date("Y"); ?> CtrlPanel | installer v2.0.0
    </footer>

    </body>
</html>
